document.getElementById('kritikForm').addEventListener('submit', function(e){
    e.preventDefault();
    document.getElementById('thanks').textContent = "Terima kasih atas kritik & saran Anda!";
    this.reset();
});
